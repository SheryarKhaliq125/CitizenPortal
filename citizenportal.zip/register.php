<?php
include 'client/scripts/connection.php';
$UserName = $_POST['formname'];
$UserEmail = $_POST['form3email'];
$UserPassword = $_POST['formpassword'];
$UserAgreement = $_POST['form2Eagreements'];

$pic_name=$_FILES['pic']['name'];
$pic_type = $_FILES['pic']['type'];
$pic_size=$_FILES['pic']['size'];
$pic_tmpname= $_FILES['pic']['tmp_name'];
if($pic_size<10000000 && $pic_type=="image/png" or $pic_type=="image/jpg" or $pic_type=="image/jpeg" )
{ 
    $destination= "uploads/".rand().$pic_name; move_uploaded_file($pic_tmpname,$destination);
$query="INSERT INTO `citi_cportal`.`cp_users` (`UserName`, `UserEmail`,`UserPassword`,`UserAgreement`,`UserPhoto`,`Role`) VALUES ('$UserName', '$UserEmail', '$UserPassword', '$UserAgreement', '$destination','user')";

}
$sql = "SELECT * FROM cp_users";
$result = mysqli_query($connection,$sql);

while ($row = mysqli_fetch_array($result)) 
{
    if($row["UserEmail"] == $UserEmail)
    {
        $userexist="AccountNotRegistered";
        header('Location: register.html?notification='.$userexist);
        return 0;
    }
}

mysqli_query($connection,$query);
header('Location: register.html?username='.$UserName);

?>