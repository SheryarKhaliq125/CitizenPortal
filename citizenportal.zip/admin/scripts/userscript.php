<?php
error_reporting(0);
session_start(); 

if(is_null($_SESSION["UserEmail"]))
{ ?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php } 
else if($_SESSION["Role"]=="admin")
{
?>
<main style="margin-top: 58px">
<div class="container pt-4">
<section style="background-color: #eee;">
<div class="container py-4">
<div class="row">
    <div class="col">
      <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4">
        <ol class="breadcrumb mb-0">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">Users</li>
        </ol>
      </nav>
    </div>
  </div>
  <center><h1>List of all Users</h1></center>
  <!--Table-->
  
<center><table class="table table-striped " >

<!--Table head-->
<thead>
<tr>
  <th>#</th>
  <th>Full Name</th>
  <th>Email</th>
  <th>Role</th>
</tr>
</thead>
<!--Table head-->

<!--Table body-->

<tbody>
<?php 
include 'connection.php';
$query = "SELECT * FROM cp_users";
$result = mysqli_query($connection,$query);
if ($_GET["userid"]!=NULL)
{
    $uid = $_GET["userid"];
    $uRole = $_GET["userrole"];
    $updatequery4 = "UPDATE cp_users SET Role='$uRole' WHERE UserID='$uid'";
    mysqli_query($connection,$updatequery4); 
    echo "<meta http-equiv=\"refresh\" content=\"0;URL=users.php\">";
}
while ($row = mysqli_fetch_array($result)) 
{?>
<tr class="table-info">
  <th scope="row"><?php echo $row["UserID"] ?></th>
  <td><?php echo $row["UserName"] ?></td>
  <td><?php echo $row["UserEmail"] ?></td>
  <?php if($row["Role"] == "admin" && $_SESSION["UserEmail"]!=$row["UserEmail"])
  {?>
  <td style="color:red"><?php echo $row["Role"] ?></td>
  <td><a href="users.php?userid=<?php echo $row["UserID"]?>&userrole=user"><button style="width: 75%;" type="button" class="btn btn-primary me-3">
    Remove from admin 
   </button></a></td>
  <?php }
  else if ($row["Role"] == "user" && $_SESSION["UserEmail"]!=$row["UserEmail"])
  {?>
 <td style="color:green"><?php echo $row["Role"] ?></td>
 <td><a href="users.php?userid=<?php echo $row["UserID"]?>&userrole=admin"><button style="width: 75%;" type="button" class="btn btn-danger me-3">
    Give Admin Access 
   </button></a></td>
 <?php }
 else
 {?>
<td style="color:red"><?php echo $row["Role"] ?></td>
 <?php } ?>
</tr>
<?php } ?>
</tbody>

<!--Table body-->


</table></center>
<!--Table-->
</div>
</section>
</div>
</main>
<script type="text/javascript">
document.getElementById("DashBoardButton").setAttribute("class","list-group-item list-group-item-action py-2 ripple inactive")
document.getElementById("UsersList").setAttribute("class","list-group-item list-group-item-action py-2 ripple active")

document.getElementById("myprofile").setAttribute("class","dropdown-item inactive")
</script>
<?php }
else
{
?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php }
?>