
<?php
error_reporting(0);
session_start(); 

if(is_null($_SESSION["UserEmail"]))
{ ?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php } 
else if($_SESSION["Role"]=="admin")
{

include 'connection.php';
$complaints = "SELECT * FROM cp_complaints";
$cresult = mysqli_query($connection,$complaints);
while ($crow = mysqli_fetch_array($cresult)) 
{
    if($crow["CID"] == $_GET["compid"] )
  {
    $Username = $crow["CUserName"];
    $Email = $crow["CEmail"];
    $CMemberType = $crow["CMemberType"];
    $CType = $crow["CType"];
    $CSubject = $crow["CSubject"];
    $CAddress = $crow["CAddress"];
    $CMessage = $crow["CMessage"];
    $Status = $crow["Status"];
  }
}
?>

<div id="ComplaintRegister">
    <main style="margin-top: 58px">
    
  <div class="container h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-xl-9">



        <div class="card" style="border-radius: 15px;">
          <div class="card-body">

            <div class="row align-items-center pt-4 pb-3">
                
            <div class="px-5 py-4">
                
              <center><td><a href="#"><button style="width: 25%;" type="button" 
  <?php if($Status!="pending") 
  { ?>
  class="btn btn-success me-3">
<?php }
else
{ ?> class="btn btn-danger me-3">
 
<?php } ?>
  <?php echo $Status ?> 
   </button></a></td></center>
            </div>
           
              <div class="col-md-3 ps-5">
                        
                <h6 class="mb-0">Complaint ID</h6>

              </div>
              <div class="col-md-9 pe-5">

                <input type="text" value="<?php echo $_GET["compid"]?>" placeholder="<?php echo $_GET["compid"]?>" class="form-control form-control-lg" disabled/>

              </div>
            </div>
            
            <div class="row align-items-center pt-4 pb-3">
              <div class="col-md-3 ps-5">

                <h6 class="mb-0">Subject</h6>

              </div>
              <div class="col-md-9 pe-5">

                <input type="text" value="<?php echo $CSubject?>"class="form-control form-control-lg" disabled/>

              </div>
            </div>
            
            <div class="row align-items-center pt-4 pb-3">
              <div class="col-md-3 ps-5">

                <h6 class="mb-0">Message</h6>

              </div>
              <div class="col-md-9 pe-5">

                <textarea class="form-control" placeholder="<?php echo $CMessage?>" disabled rows="10" ></textarea>

              </div>
              
            </div>
            
            <div class="row align-items-center pt-4 pb-3">
              <div class="col-md-3 ps-5">

                <h6 class="mb-0">Member Type</h6>

              </div>
              <div class="col-md-9 pe-5">

                <input type="text" class="form-control form-control-lg" placeholder="<?php echo $CMemberType?>" disabled />

              </div>
            </div>
            
            <div class="row align-items-center pt-4 pb-3">
              <div class="col-md-3 ps-5">

                <h6 class="mb-0">Complaint Type</h6>

              </div>
              <div class="col-md-9 pe-5">

                <input type="text" class="form-control form-control-lg" placeholder="<?php echo $CType?>" disabled />

              </div>
            </div>
            
            <div class="row align-items-center pt-4 pb-3">
              <div class="col-md-3 ps-5">

                <h6 class="mb-0">Address</h6>

              </div>
              <div class="col-md-9 pe-5">

                <input type="text" class="form-control form-control-lg" placeholder="<?php echo $CAddress?>" disabled />

              </div>
            </div>
            

            <div class="row align-items-center py-3">
              <div class="col-md-3 ps-5">

                <h6 class="mb-0">Email address</h6>

              </div>
              <div class="col-md-9 pe-5">

                <input type="email" class="form-control form-control-lg" placeholder="<?php echo $Email?>" disabled/>

              </div>
            </div>
            
            <div class="row align-items-center pt-4 pb-3">
              <div class="col-md-3 ps-5">

                <h6 class="mb-0">Registered By</h6>

              </div>
              <div class="col-md-9 pe-5">

                <input type="text" class="form-control form-control-lg" placeholder="<?php echo $Username?>" disabled/>

              </div>
            </div>
            
            


          </div>
        </div>

      </div>
    </div>
  </div>
</section>
        <!--Section: Statistics with subtitles-->
        
      </center>
    </div>
  </div>
  <script>
  document.getElementById("DashBoardButton").setAttribute("class","list-group-item list-group-item-action py-2 ripple inactive")
  /* Complaints update soon*/
  /* users update soon*/
 
</script>

<?php }
else
{
?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php }
?>
