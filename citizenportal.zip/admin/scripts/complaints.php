<?php
error_reporting(0);
session_start(); 

if(is_null($_SESSION["UserEmail"]))
{ ?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php } 
else if($_SESSION["Role"]=="admin")
{
?>
<main style="margin-top: 58px">
<div class="container pt-4">
  
<section style="background-color: #eee;">
<div class="container py-4">
<div class="row">
    <div class="col">
      <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4">
        <ol class="breadcrumb mb-0">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">Complaints</li>
        </ol>
      </nav>
    </div>
  </div>
  <?php 
include 'connection.php';
$query = "SELECT * FROM cp_complaints";
$result = mysqli_query($connection,$query);
$count=0;
while ($row = mysqli_fetch_array($result)) 
{?>
<?php if($_SESSION["UserEmail"]!=NULL)
{
$count++;

if ($count<=1)
{?>
  <center><h1>List of all Complaints</h1></center>
  <!--Table-->
<center><table class="table table-striped " >

<!--Table head-->
<thead>
<tr>
  <th>#</th>
  <th>Complaint Type</th>
  <th>Subject</th>
  <th>Status</th>
</tr>
</thead>
<!--Table head-->
<?php }?>
<!--Table body-->
<tbody class="table-info">
<tr >
  <th scope="row"><a href="#"><?php echo $row["CID"] ?></a></th>
  <td><?php echo $row["CType"] ?></td>
  <td><?php echo $row["CSubject"] ?> </td>
  <td><a href="#"><button style="width: 75%;" type="button" 
  <?php if($row["Status"]!="pending") 
  { ?>
  class="btn btn-success me-3">
<?php }
else
{ ?> class="btn btn-danger me-3">
 
<?php } ?>
  <?php echo $row["Status"] ?> 
   </button></a></td>
   <td><a href="complaintview.php?compid=<?php echo $row["CID"]?>"><button style="width: 75%;" type="button" class="btn btn-primary me-3">
    Click here to view 
   </button></a></td>
</tr>
<?php 
}
}
if($count>0)
{

}
else 
{ ?>
<h3> You have no complaints registered!</h1>
<?php }?>

</tbody>
<!--Table body-->


</table></center>
<!--Table-->
</div>
</section>
</div>
</main>
<script>
document.getElementById("DashBoardButton").setAttribute("class","list-group-item list-group-item-action py-2 ripple inactive")
document.getElementById("UsersList").setAttribute("class","list-group-item list-group-item-action py-2 ripple inactive")
document.getElementById("ComplaintsList").setAttribute("class","list-group-item list-group-item-action py-2 ripple active")
document.getElementById("myprofile").setAttribute("class","dropdown-item inactive")
</script>

<?php }
else
{
?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php }
?>