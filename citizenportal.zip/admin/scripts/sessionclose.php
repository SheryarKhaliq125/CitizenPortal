<?php 
session_start();
unset($_SESSION["UserName"]);
unset($_SESSION["UserEmail"]);
unset($_SESSION["UserPhoto"]);
unset($_SESSION["Role"]);
$msg="Logout";
header('Location: https://citizenportal.xyz/?notification='.$msg);
?>
