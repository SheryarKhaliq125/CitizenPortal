
<?php
error_reporting(0);
session_start(); 

if(is_null($_SESSION["UserEmail"]))
{ ?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php } 
else if($_SESSION["Role"]=="admin")
{

if(is_null($_POST['formpassword']))
{
}
else
{
include 'connection.php';
$UserName = $_POST['formname'];
$Email = $_POST['form3email'];
$password = $_POST['formpassword'];
$users = "SELECT * FROM cp_users";
$result = mysqli_query($connection,$users);

while($row = mysqli_fetch_array($result))
{
    if($row["UserEmail"]== $_SESSION["UserEmail"] && $row["UserPassword"]== $password)
    {
        $id = $row["UserID"];
        $updatequery1 = "UPDATE cp_users SET UserName='$UserName' WHERE UserID='$id'";
        mysqli_query($connection,$updatequery1);
        $updatequery2 = "UPDATE cp_users SET UserEmail='$Email' WHERE UserID='$id'";
        mysqli_query($connection,$updatequery2);
        $sucessful=1;
        $complaints = "SELECT * FROM cp_complaints";
        $cresult = mysqli_query($connection,$complaints);
        while ($crow = mysqli_fetch_array($cresult)) 
{
  if($crow["CEmail"] == $_SESSION["UserEmail"] )
  {
    $compid = $crow["CID"];
    $updatequery3 = "UPDATE cp_complaints SET CEmail='$Email' WHERE CID='$compid'";
    mysqli_query($connection,$updatequery3);
    $updatequery4 = "UPDATE cp_complaints SET CUserName='$UserName' WHERE CID='$compid'";
    mysqli_query($connection,$updatequery4);
  }
}
    }


}

if($sucessful==1)
{
    $_SESSION["UserName"] = $_POST['formname'];
    $_SESSION["UserEmail"] = $_POST['form3email'];
?>
<script>alert('Your profile have been sucessfully updated!') </script>
<?php 
}
else
{ ?>

    <script>alert('Password is incorrect!') </script>
<?php }
}?>
<div id="ComplaintRegister">
<main style="margin-top: 48px">

<section style="background-color: #eee;">
<div class="container py-4">
  <div class="row">
    <div class="col">
      <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4">
        <ol class="breadcrumb mb-0">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item"><a href="users.php">Users</a></li>
          <li class="breadcrumb-item"><a href="myprofile.php">My Profile</a></li>
          <li class="breadcrumb-item active" aria-current="page">Edit Profile</li>
        </ol>
      </nav>
    </div>
  </div>
        
  
  
  
        <!--Section: Admins/clients/resolved/pending complaints-->
        <section>
          <center><div class="row" style="width: 60%;">
            <!-- Default form contact -->
            <form name="registerform" enctype="multipart/form-data" class="bg-white rounded shadow-5-strong p-5" method="post" action="editprofile.php">
                <center><h1> Edit Profile</h1></center>
                <hr>
                <div class="d-flex flex-row align-items-center mb-4">
                  <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                  <div class="form-outline flex-fill mb-0">
                    <input type="text" name="formname" class="form-control" maxlength="50" value="<?php echo $_SESSION["UserName"]?>" placeholder="<?php echo $_SESSION["UserName"]?>" required/>
                    <label class="form-label" for="form3Example1c">Your Name*</Name></label>
                  </div>
                </div>

                <div class="d-flex flex-row align-items-center mb-4">
                  <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                  <div class="form-outline flex-fill mb-0">
                    <input type="email" name="form3email" class="form-control" value="<?php echo $_SESSION["UserEmail"]?>" placeholder="<?php echo $_SESSION["UserEmail"]?>" maxlength="100" required/>
                    <label class="form-label" for="form3Example3c">Your Email*</label>
                  </div>
                </div>

                <div class="d-flex flex-row align-items-center mb-4">
                  <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                  <div class="form-outline flex-fill mb-0">
                    <input type="password" name="formpassword" id="form3password" class="form-control" maxlength="30" required/>
                    <label class="form-label" for="form3Example4c">Type Current password to update profile</label>
                  </div>
                </div>


                <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                  <button type="submit"  class="btn btn-primary btn-lg">Update Now</button> 
                </div>

              </form>
  <!-- Default form contact -->
          </div>
        </section>
        <!--Section: Statistics with subtitles-->
        
      </center>
    </div>
  </div>
  <script>
  document.getElementById("DashBoardButton").setAttribute("class","list-group-item list-group-item-action py-2 ripple inactive")
  /* Complaints update soon*/
  /* users update soon*/
  
</script>

<?php }
else
{
?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php }
?>