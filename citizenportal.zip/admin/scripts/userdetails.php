<?php
error_reporting(0);
session_start(); 

if(is_null($_SESSION["UserEmail"]))
{ ?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php } 
else if($_SESSION["Role"]=="admin")
{

include 'connection.php';
$complaints = "SELECT * FROM cp_complaints";
$pendingcount =0;
$resolvecount=0;
$totalcomplaints=0;
$result = mysqli_query($connection,$complaints);
while ($row = mysqli_fetch_array($result)) 
{
  if($row["CEmail"] == $_SESSION["UserEmail"] && $row["Status"] == 'pending')
  {
    $pendingcount++;
  }
  else if ($row["CEmail"] == $_SESSION["UserEmail"] && $row["Status"] == 'resolved')
  {
    $resolvecount++;
  }
}
$users = "SELECT * FROM cp_users";
$result = mysqli_query($connection,$users);
while($row = mysqli_fetch_array($result))
{
    if($row["UserEmail"]== $_SESSION["UserEmail"])
    {
        $userID = $row["UserID"];
        $userRole = $row["Role"];
        $picture = $row["UserPhoto"];
    }
}
$totalcomplaints = $resolvecount + $pendingcount;
}
else
{
?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php }
?>