<?php
error_reporting(0);
session_start(); 

if(is_null($_SESSION["UserEmail"]))
{ ?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php } 
else if($_SESSION["Role"]=="admin")
{
 include('rolecount.php'); 
  ?>

<main style="margin-top: 58px">
        <div class="container pt-4">
    
    
    
          <!--Section: Admins/clients/resolved/pending complaints-->
          <section>
            <div class="row">
            <h3>Welcome <?php echo $_SESSION["UserName"]?>!</h3>
		<center><h3>CPortal World Statistics</h3></center>
              <div class="col-xl-6 col-md-12 mb-4">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between px-md-1">
                      <div>
                        <h3 class="text-warning"><?php echo $admincount?></h3>
                        <p class="mb-0">Administrators</p>
                      </div>
                      <div class="align-self-center">
                        <i class="fas fa-user text-warning fa-3x"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-xl-6 col-md-12 mb-4">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between px-md-1">
                      <div>
                        <h3 class="text-info"><?php echo $usercount ?></h3>
                        <p class="mb-0">Clients</p>
                      </div>
                      <div class="align-self-center">
                        <i class="far fa-user text-info fa-3x"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
             
            </div>
            <div class="row">
              
              <div class="col-xl-6 col-md-12 mb-4">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between px-md-1">
                      <div>
                        <h3 class="text-success"><?php echo $resolvecount?></h3>
                        <p class="mb-0">Resolved Complaints</p>
                      </div>
                      <div class="align-self-center">
                        <i class="far fa-comments text-success fa-3x"></i>
                      </div>
                    </div>
                    <div class="px-md-1">
                      <div class="progress mt-3 mb-1 rounded" style="height: 7px">
                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $resolvecount?>%" aria-valuenow="0"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-xl-6 col-md-12 mb-4">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between px-md-1">
                      <div>
                        <h3 class="text-danger"><?php echo $pendingcount?></h3>
                        <p class="mb-0">Pending Complaints</p>
                      </div>
                      <div class="align-self-center">
                        <i class="far fa-comments text-danger fa-3x"></i>
                      </div>
                    </div>
                    <div class="px-md-1">
                      <div class="progress mt-3 mb-1 rounded" style="height: 7px">
                        <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo $pendingcount?>%" aria-valuenow="0"
                          aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
                        </div>
            </div>
          </section>
          <!--Section: Admins/clients/resolved/pending complaints-->
    
          <!--Section: Statistics of Users and Complaints-->
          <section>
            <div class="row">
              <div class="col-xl-6 col-md-12 mb-4">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between p-md-1">
                      <div class="d-flex flex-row">
                        <div class="align-self-center">
                          <i class="fas fa-pencil-alt text-info fa-3x me-4"></i>
                        </div>
                        <div>
                          <h4>Total Users</h4>
                          <p class="mb-0">Registered</p>
                        </div>
                      </div>
                      <div class="align-self-center">
                        <h2 class="h1 mb-0"><?php echo $totalusers ?></h2>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-xl-6 col-md-12 mb-4">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between p-md-1">
                      <div class="d-flex flex-row">
                        <div class="align-self-center">
                          <i class="far fa-comment-alt text-warning fa-3x me-4"></i>
                        </div>
                        <div>
                          
                          <h4>Total Complaints</h4>
                          <p class="mb-0">Registered</p>
                        </div>
                      </div>
                      <div class="align-self-center">
                        <h2 class="h1 mb-0"><?php echo $totalcomplaints?></h2>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </div>
          </section>
          <!--Section: Statistics with subtitles-->
          
        </div>
        
      </main>

      <?php }
else
{
?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php }
?>