
<?php
error_reporting(0);
session_start(); 

if(is_null($_SESSION["UserEmail"]))
{ ?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php } 
else if($_SESSION["Role"]=="admin")
{


include('userdetails.php'); 
  ?>
<main style="margin-top: 58px">
<div class="container pt-4">
<section style="background-color: #eee;">
<div class="container py-4">
  <div class="row">
    <div class="col">
      <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4">
        <ol class="breadcrumb mb-0">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item"><a href="users.php">Users</a></li>
          <li class="breadcrumb-item active" aria-current="page">My Profile</li>
        </ol>
      </nav>
    </div>
  </div>

  <div class="row">
    <div class="col-lg-4">
      <div class="card mb-4">
        <div class="card-body text-center">
          <img src="https://citizenportal.xyz/<?php echo $picture?>" alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
          <h5 class="my-3"><?php echo $_SESSION["UserName"]?></h5>
          <p style="color: red"><?php echo $userRole?></p>
          <div class="d-flex justify-content-center mb-2">
            <a href="editprofile.php"><button type="button" class="btn btn-primary">Edit Profile</button></a>
            
          </div>
        </div>
      </div>
      
    </div>
    <div class="col-lg-8">
      <div class="card mb-4">
        <div class="card-body">
        <div class="row">
            <div class="col-sm-3">
              <p class="mb-0">User ID</p>
            </div>
            <div class="col-sm-9">
              <p class="text-muted mb-0"><?php echo $userID?></p>
            </div>
          </div>
        <hr>
          <div class="row">
            <div class="col-sm-3">
              <p class="mb-0">Full Name</p>
            </div>
            <div class="col-sm-9">
              <p class="text-muted mb-0"><?php echo $_SESSION["UserName"]?></p>
            </div>
          </div>
          <hr>
          <div class="row">
            <div class="col-sm-3">
              <p class="mb-0">Email</p>
            </div>
            <div class="col-sm-9">
              <p class="text-muted mb-0"><?php echo $_SESSION["UserEmail"]?></p>
            </div>
          </div>

         
          
          <div class="row">
            
          </div>
        </div>
      </div>
      
      </div>
      </div>
    </div>
  </div>
</div>
</section>
</div>
</main> 
<script>
document.getElementById("DashBoardButton").setAttribute("class","list-group-item list-group-item-action py-2 ripple inactive")
 document.getElementById("myprofile").setAttribute("class","dropdown-item active")
 </script>
 <?php }
else
{
?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php }
?>