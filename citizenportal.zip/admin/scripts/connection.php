<?php
$connection=mysqli_connect("localhost","citi_cportal","CBrOdv#x*8-lL^hw","citi_cportal");
if (!$connection)
{ die("Connection failed: " . mysqli_connect_error()); }
else
{
    $ctable="CREATE TABLE `cp_complaints` (
        `CID` int NOT NULL AUTO_INCREMENT,
        `CUserName` varchar(50) NOT NULL,
        `CEmail` varchar(50) NOT NULL,
        `CMemberType` varchar(30) NOT NULL,
        `CType` varchar(30) NOT NULL,
        `CSubject` varchar(100) NOT NULL,
        `CAddress` varchar(100) NOT NULL,
        `CMessage` varchar(350) NOT NULL,
        `Status` varchar(10) NOT NULL,
        PRIMARY KEY (CID)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    mysqli_query($connection,$ctable);
    $utable="CREATE TABLE `cp_users` (
        `UserID` int NOT NULL AUTO_INCREMENT,
        `UserName` varchar(50) NOT NULL,
        `UserEmail` varchar(100) NOT NULL,
        `UserPassword` varchar(30) NOT NULL,
        `UserAgreement` varchar(100) NOT NULL,
        `UserPhoto` varchar(100) NOT NULL,
        `Role` varchar(10) NOT NULL,
        PRIMARY KEY (UserID)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    mysqli_query($connection,$utable);
}
?>