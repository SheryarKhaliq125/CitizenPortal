<?php
error_reporting(0);
session_start(); 

if(is_null($_SESSION["UserEmail"]))
{ ?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php } 
else if($_SESSION["Role"]=="admin")
{

include 'connection.php';
$users = "SELECT * FROM cp_users";
$complaints = "SELECT * FROM cp_complaints";
$result = mysqli_query($connection,$users);
$admincount = 0;
$usercount = 0; 
$pendingcount =0;
$resolvecount=0;
$totalcomplaints=0;
$totalusers = 0;
$userpcomplaints = 0;
$userrcomplaints = 0;
$usertcomplaints = 0;

while ($row = mysqli_fetch_array($result)) 
{
  if($row["Role"] == 'admin')
  {
    $admincount++;
  }
  else
  {
    $usercount++;
  }
  $totalusers++;
}
$result = mysqli_query($connection,$complaints);
while ($row = mysqli_fetch_array($result)) 
{
  if($row["CEmail"] == $_SESSION["UserEmail"] &&  $row["Status"] == 'pending')
  {
    $userpcomplaints++;
    $usertcomplaints++;
  }
  else if ($row["CEmail"] == $_SESSION["UserEmail"] &&  $row["Status"] == 'resolved')
  {
    $userrcomplaints++;
    $usertcomplaints++;
  }

  if($row["Status"] == 'pending')
  {
    $pendingcount++;
  }
  else
  {
    $resolvecount++;
  }
  $totalcomplaints++;
}
}
else
{
?>
  <h1> <center>You are not authorized to access this page</center></h1>
  <br>
  <h4><center><a href="https://citizenportal.xyz/"> Click here to return to login page! </a></center></h4>
<?php }
?>