<?php 

session_start();
$_SESSION["UserName"] = $_POST['userName'];
$_SESSION["UserEmail"] = $_POST['userEmail'];
$_SESSION["UserPhoto"] = $_POST['PhotoDestination'];
$_SESSION["Role"] = $_POST['Role'];
header('Location: index.php');
?>
