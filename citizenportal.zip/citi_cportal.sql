-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: citizenportal.xyz
-- Generation Time: Jan 16, 2022 at 05:56 PM
-- Server version: 10.5.13-MariaDB
-- PHP Version: 7.3.33-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `citi_cportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `cp_complaints`
--

CREATE TABLE `cp_complaints` (
  `CID` int(3) NOT NULL,
  `CUserName` varchar(50) NOT NULL,
  `CEmail` varchar(50) NOT NULL,
  `CMemberType` varchar(30) NOT NULL,
  `CType` varchar(30) NOT NULL,
  `CSubject` varchar(100) NOT NULL,
  `CAddress` varchar(100) NOT NULL,
  `CMessage` varchar(350) NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cp_complaints`
--


-- --------------------------------------------------------

--
-- Table structure for table `cp_users`
--

CREATE TABLE `cp_users` (
  `UserID` int(3) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `UserEmail` varchar(100) NOT NULL,
  `UserPassword` varchar(30) NOT NULL,
  `UserAgreement` varchar(100) NOT NULL,
  `UserPhoto` varchar(100) NOT NULL,
  `Role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cp_users`
--


--
-- Indexes for dumped tables
--

--
-- Indexes for table `cp_complaints`
--
ALTER TABLE `cp_complaints`
  ADD PRIMARY KEY (`CID`);

--
-- Indexes for table `cp_users`
--
ALTER TABLE `cp_users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cp_complaints`
--
ALTER TABLE `cp_complaints`
  MODIFY `CID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cp_users`
--
ALTER TABLE `cp_users`
  MODIFY `UserID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
