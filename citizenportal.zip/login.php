<?php
include 'client/scripts/connection.php';
$query = "SELECT * FROM cp_users";
$result = mysqli_query($connection,$query);

$UserEmail = $_POST['userEmail'];
$UserPassword = $_POST['userPassword'];

while ($row = mysqli_fetch_array($result)) 
{
    if($row["UserEmail"] == $UserEmail && $row["UserPassword"]==$UserPassword && $row["Role"]=="user")
    {?>
<form id="loginsucessful" enctype="multipart/form-data" method="POST" action="client/session.php" class="bg-white rounded shadow-5-strong p-5" >
<input type="hidden" name="userName" value="<?php echo $row["UserName"]?>">
<input type="hidden" name="userEmail" value="<?php echo $row["UserEmail"]?>">
<input type="hidden" name="PhotoDestination" value="<?php echo $row["UserPhoto"]?>">
<input type="hidden" name="Role" value="<?php echo $row["Role"]?>">
</form>
<script type="text/javascript"> 
document.getElementById("loginsucessful").submit();
</script>
    <?php 
    return 0;
}
else if($row["UserEmail"] == $UserEmail && $row["UserPassword"]==$UserPassword && $row["Role"]=="admin")
{?>
    <form id="loginsucessful" enctype="multipart/form-data" method="POST" action="admin/session.php" class="bg-white rounded shadow-5-strong p-5" >
    <input type="hidden" name="userName" value="<?php echo $row["UserName"]?>">
    <input type="hidden" name="userEmail" value="<?php echo $row["UserEmail"]?>">
    <input type="hidden" name="PhotoDestination" value="<?php echo $row["UserPhoto"]?>">
    <input type="hidden" name="Role" value="<?php echo $row["Role"]?>">
    </form>
    <script type="text/javascript"> 
    document.getElementById("loginsucessful").submit();
    </script>
        <?php 
        return 0;
}

}
$msg="Failed";
header('Location: index.html?notification='.$msg);

?>

